//
//  TrackTargetType.swift
//  Example
//
//  Created by HOANDHTB on 3/6/21.
//  Copyright © 2021 HOANDHTB. All rights reserved.
//

import UIKit
import APIManager
import Moya

enum TrackTargetType {
    case signIn(username: String, password: String)
}

extension TrackTargetType: BaseTargetType {
    var baseURL: URL {
        return URL(string: Constants.baseURL)!
    }
    
    var path: String {
        switch self {
        case .signIn:
            return Constants.pathSignin
        default:
            return ""
        }
    }
    
    var method: Moya.Method {
        switch self {
        case .signIn:
            return .post
        default:
            return .get
        }
    }
    
    var headers: [String : String]? {
        return nil
    }
    
    var parameters: [String : Any]? {
        switch self {
        case .signIn(let username, let password):
            var paramester: [String: Any]?{
                var parameter:[String:Any] = [:]
                parameter["email"] = username
                parameter["password"] = password
                return parameter
            }
            return paramester
        default:
            return nil
        }
    }
    
    var parameterEncoding: ParameterEncoding {
        switch self {
        case .signIn:
            return JSONEncoding.default
        default:
            return URLEncoding.default
        }
    }
}
