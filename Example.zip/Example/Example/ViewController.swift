//
//  ViewController.swift
//  Example
//
//  Created by HOANDHTB on 3/6/21.
//  Copyright © 2021 HOANDHTB. All rights reserved.
//

import UIKit
import APIManager
import RxSwift

class ViewController: UIViewController {
    let disposeBag: DisposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.testCallAPI()
        // Do any additional setup after loading the view.
    }

    fileprivate func testCallAPI() {
        TSAPIManager.share.request(api: TrackTargetType.signIn(username: "admin@gmail.com", password: "admin@123")).mapObject(SigninModelResponse.self).asObservable().subscribe(onNext: { response in
            print(response.data?.token)
        }, onError: { error in
            print("error")
        }).disposed(by: self.disposeBag)
    }
}

