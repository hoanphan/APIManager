//
//  SigninModel.swift
//  Example
//
//  Created by HOANDHTB on 3/6/21.
//  Copyright © 2021 HOANDHTB. All rights reserved.
//

import UIKit
import  ObjectMapper

class SigninModel: Mappable {
    required convenience init?(map: Map) {
        self.init()
    }
    
    var token: String?
    var expire: String?
    var email: String?
    
    func mapping(map: Map) {
        self.token <- map["token"]
        self.email <- map["email"]
        self.expire <- map["expire"]
    }
}

class SigninModelResponse: Mappable {
    var success: Bool?
    var data: SigninModel?
    var code: String?
    var message: String?
    
    
    required convenience init?(map: Map) {
        self.init()
    }
    
    func mapping(map: Map) {
        self.success <- map["success"]
        self.data <- map["data"]
        self.code <- map["code"]
        self.message <- map["code"]
    }
}
